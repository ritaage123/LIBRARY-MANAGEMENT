#include <iostream>
#include <vector>
#include <string>

class Book {
public:
    Book(std::string title, std::string author, int year) : title(title), author(author), year(year) {}

    std::string getTitle() const {
        return title;
    }

    std::string getAuthor() const {
        return author;
    }

    int getYear() const {
        return year;
    }

private:
    std::string title;
    std::string author;
    int year;
};

class Library {
public:
    void addBook(const Book& book) {
        books.push_back(book);
    }

    void displayBooks() const {
        std::cout << "Library Books:" << std::endl;
        for (size_t i = 0; i < books.size(); ++i) {
            const Book& book = books[i];
            std::cout << "Title: " << book.getTitle() << ", Author: " << book.getAuthor() << ", Year: " << book.getYear() << std::endl;
        }
    }

    std::vector<Book> searchByTitle(const std::string& title) const {
        std::vector<Book> foundBooks;
        for (size_t i = 0; i < books.size(); ++i) {
            const Book& book = books[i];
            if (book.getTitle() == title) {
                foundBooks.push_back(book);
            }
        }
        return foundBooks;
    }

private:
    std::vector<Book> books;
};

int main() {
    Library library;

    while (true) {
        std::cout << "Menu:" << std::endl;
        std::cout << "1. Add Book" << std::endl;
        std::cout << "2. Display Books" << std::endl;
        std::cout << "3. Search by Title" << std::endl;
        std::cout << "4. Exit" << std::endl;

        int choice;
        std::cin >> choice;

        if (choice == 1) {
            std::string title, author;
            int year;
            std::cout << "Enter Title: ";
            std::cin.ignore();
            std::getline(std::cin, title);
            std::cout << "Enter Author: ";
            std::getline(std::cin, author);
            std::cout << "Enter Year: ";
            std::cin >> year;
            Book newBook(title, author, year);
            library.addBook(newBook);
            std::cout << "Book added successfully!" << std::endl;
        } else if (choice == 2) {
            library.displayBooks();
        } else if (choice == 3) {
            std::string searchTitle;
            std::cout << "Enter Title to Search: ";
            std::cin.ignore();
            std::getline(std::cin, searchTitle);
            std::vector<Book> foundBooks = library.searchByTitle(searchTitle);
            if (foundBooks.empty()) {
                std::cout << "No books found with the given title." << std::endl;
            } else {
                std::cout << "Books Found:" << std::endl;
                for (size_t i = 0; i < foundBooks.size(); ++i) {
                    const Book& book = foundBooks[i];
                    std::cout << "Title: " << book.getTitle() << ", Author: " << book.getAuthor() << ", Year: " << book.getYear() << std::endl;
                }
            }
        } else if (choice == 4) {
            break;
        } else {
            std::cout << "Invalid choice. Please enter a valid option." << std::endl;
        }
    }

    return 0;
}

